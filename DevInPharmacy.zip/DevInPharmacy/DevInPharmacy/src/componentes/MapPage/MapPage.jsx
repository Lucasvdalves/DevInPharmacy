import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet'; 
import Navbar from '../NavbarTelaDeCadastro/NavbarTelaDeCadastro';
import MenuLateral from '../MenuLateral/MenuLateral';

const pharmacies = [
  {
    id: 1,
    name: 'Farmácia A',
    latitude: -23.550520,
    longitude: -46.633308,
    razaoSocial: 'Farmácia A Ltda',
    cnpj: '12.345.678/0001-01',
    telefone: '(11) 98765-4321',
  },
  {
    id: 2,
    name: 'Farmácia B',
    latitude: -23.560520,
    longitude: -46.623308,
    razaoSocial: 'Farmácia B Ltda',
    cnpj: '98.765.432/0001-21',
    telefone: '(11) 98765-1234',
  },
  {
    id: 3,
    name: 'Farmácia C',
    latitude: -23.545678,
    longitude: -46.640000,
    razaoSocial: 'Farmácia C Ltda',
    cnpj: '36.985.124/0001-10',
    telefone: '(11) 92345-6789',
  },
  {
    id: 4,
    name: 'Farmácia D',
    latitude: -23.552345,
    longitude: -46.632345,
    razaoSocial: 'Farmácia D Ltda',
    cnpj: '25.678.983/0001-77',
    telefone: '(11) 94567-8901',
  },
  {
    id: 5,
    name: 'Farmácia E',
    latitude: -23.565678,
    longitude: -46.610987,
    razaoSocial: 'Farmácia E Ltda',
    cnpj: '19.876.543/0001-02',
    telefone: '(11) 90123-4567',
  },

    {
      id: 6,
      name: 'Farmácia X',
      latitude: -23.567890,
      longitude: -46.655432,
      razaoSocial: 'Farmácia X Ltda',
      cnpj: '45.678.912/0001-99',
      telefone: '(11) 98876-5432',
    },
    {
      id: 7,
      name: 'Farmácia Y',
      latitude: -23.578901,
      longitude: -46.642345,
      razaoSocial: 'Farmácia Y Ltda',
      cnpj: '12.345.678/0001-01',
      telefone: '(11) 91234-5678',
      // Outras informações da farmácia
    },
    {
      id: 8,
      name: 'Farmácia Z',
      latitude: -23.570987,
      longitude: -46.625678,
      razaoSocial: 'Farmácia Z Ltda',
      cnpj: '11.223.344/0001-55',
      telefone: '(11) 99887-7766',
    },

];
const redHouseIcon = new L.Icon({
  iconUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Map_marker.svg/1200px-Map_marker.svg.png', 
  iconSize: [32, 32],
  iconAnchor: [16, 32], 
});

const MapPage = () => {
  return (
    <div 
    
    style={{ width: '85vw', height: '90vh', marginTop: '80px', marginLeft: '250px' }}>
      <MapContainer
        center={[-23.550520, -46.633308]}
        zoom={12}
        style={{ width: '100%', height: '100%' }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        {pharmacies.map(pharmacy => (
          <Marker
            key={pharmacy.id}
            position={[pharmacy.latitude, pharmacy.longitude]}
            icon={redHouseIcon} 
          >
            <Popup>
              <div>
                <h2>{pharmacy.name}</h2>
                {pharmacy.razaoSocial && (
                  <p>
                    <strong>Razão Social:</strong> {pharmacy.razaoSocial}
                  </p>
                )}
                {pharmacy.cnpj && (
                  <p>
                    <strong>CNPJ:</strong> {pharmacy.cnpj}
                  </p>
                )}
                {pharmacy.telefone && (
                  <p>
                    <strong>Telefone:</strong>{' '}
                    <a href={`https://wa.me/55${pharmacy.telefone.replace(/\D/g, '')}`}>
                      {pharmacy.telefone}
                    </a>
                  </p>
                )}
              </div>
            </Popup>
          </Marker>
        ))}
<h1>teste</h1>
      </MapContainer>
      <Navbar />
      <MenuLateral />
    </div>
  );
};

export default MapPage;
