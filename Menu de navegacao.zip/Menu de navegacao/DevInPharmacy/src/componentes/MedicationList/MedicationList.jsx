import React from 'react';
import MedicationCard from '../../componentes/MedicationCard/MedicationCard';

const MedicationList = ({ medications, onMedicationClick }) => {
  const medicationListStyles = {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '40px',
  };

  return (
    <div style={medicationListStyles}>
      {medications.map(medication => (
        <MedicationCard
          key={medication.id}
          medication={medication}
          onMedicationClick={onMedicationClick}
        />
      ))}
    </div>
  );
};

export default MedicationList;
