import React, { useState } from 'react';
import MenuLateral from '../../componentes/MenuLateral/MenuLateral'
import NavbarTelaDeCadastro from '../../componentes/NavbarTelaDeCadastro/NavbarTelaDeCadastro'
import Navbar from '../../componentes/NavbarTelaDeCadastro/NavbarTelaDeCadastro';

const CadastroMedicamentos = () => {
    const [formData, setFormData] = useState({
        nomeMedicamento: '',
        nomeLaboratorio: '',
        dosagem: '',
        descricao: '',
        preco: '',
        tipo: 'controlado',
    });
    const [feedbackMessage, setFeedbackMessage] = useState('');

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormData((prevData) => ({ ...prevData, [name]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        try {
            const medicamentos = JSON.parse(localStorage.getItem('medicamentos')) || [];
            const novoMedicamento = { ...formData };
            medicamentos.push(novoMedicamento);
            localStorage.setItem('medicamentos', JSON.stringify(medicamentos));

            setFeedbackMessage('Medicamento cadastrado com sucesso.');
            setTimeout(() => {
                setFeedbackMessage('');
            }, 3000); // Exibir a mensagem por 3 segundos

            // Limpar o formulário após o cadastro
            setFormData({
                nomeMedicamento: '',
                nomeLaboratorio: '',
                dosagem: '',
                descricao: '',
                preco: '',
                tipo: 'controlado',
            });
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <div style={{ maxWidth: '900px', width: '100%', margin: '0 auto', padding: '100px' }}>
            <Navbar/>
            <MenuLateral/>

            <h2 style={{ fontSize: '40px', marginBottom: '20px', textAlign: 'left' }}>Cadastro de Medicamamentos</h2>
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', width: '100%', justifyContent : '100px' }}>
                <div style={{ display: 'flex', marginBottom: '15px', justifyContent :'left', marginLeft : '0px', marginRight : '0px' }}>
                    <input type="text" name="nomeMedicamento" placeholder="Medicamento *" value={formData.nomeMedicamento} onChange={handleInputChange} style={{ flex: '1', marginRight: '10px', width: '50%' }} />
                    <input type="text" name="nomeLaboratorio" placeholder="Laboratório *" value={formData.nomeLaboratorio} onChange={handleInputChange} style={{ flex: '1', width: '50%' }} />
                </div>
                <div style={{ display: 'flex', marginBottom: '15px' }}>
                    <input type="text" name="dosagem" placeholder="Dosagem *" value={formData.dosagem} onChange={handleInputChange} style={{ flex: '1', marginRight: '10px', width: '50%' }} />
                    <select name="tipo" value={formData.tipo} onChange={handleInputChange} required style={{ flex: '1', marginRight: '10px', width: '25%' }}>
                        <option value="controlado">Medicamento controlado</option>
                        <option value="comum">Medicamento comum</option>
                    </select>
                    <input type="number" step="0.01" name="preco" placeholder="Preço Unitário *" value={formData.preco} onChange={handleInputChange} style={{ flex: '1', width: '25%' }} />
                </div>
                <div>
                    <textarea
                        name="descricao"
                        placeholder="Descrição"
                        value={formData.descricao}
                        onChange={handleInputChange}
                        style={{ width: '100%', height: '300px', margin: '0 auto', marginBottom: '10px',  }}
                    />
                </div>
                <button type="submit" style={{ padding: '8px 12px', backgroundColor: '#4a90e2', color: '#fff', border: 'none', borderRadius: '5px', cursor: 'pointer', fontSize: '14px', marginTop: '10px', width: '100px' }}>Cadastrar</button>
            </form>
            {feedbackMessage && <p style={{ color: '#ff7f7f', marginTop: '10px', fontSize: '14px', marginLeft: '50px' }}>{feedbackMessage}</p>}
        </div>
    );
};

export default CadastroMedicamentos;
