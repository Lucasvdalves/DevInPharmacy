import React, { useState } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";

const pharmacies = [
  // Lista de farmácias com informações, incluindo latitude e longitude 

  // PRECISO ACERTAR SOBRE O ESTILO DO MAPA
];

function MapPage() {
  const [selectedPharmacy, setSelectedPharmacy] = useState(null);

  const handleMarkerClick = (pharmacy) => {
    setSelectedPharmacy(pharmacy);
  };

  const popupStyles = {
    backgroundColor: "white",
    borderRadius: "5px",
    boxShadow: "0 2px 10px rgba(0, 0, 0, 0.1)",
    padding: "10px",
  };

  const closeButtonStyles = {
    position: "absolute",
    top: "5px",
    right: "10px",
    backgroundColor: "white",
    border: "1px solid #ccc",
    borderRadius: "50%",
    padding: "4px",
    fontSize: "12px",
    lineHeight: "1",
    cursor: "pointer",
  };

  const phoneLinkStyles = {
    color: "#007bff",
    textDecoration: "none",
  };

  return (
    <div style={{ height: "100vh", width: "100%" }}>
      <MapContainer center={[-23.5489, -46.6388]} zoom={13} style={{ height: "100%", width: "100%" }}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        {pharmacies.map((pharmacy) => (
          <Marker
            key={pharmacy.id}
            position={[pharmacy.latitude, pharmacy.longitude]}
            onClick={() => handleMarkerClick(pharmacy)}
          />
        ))}
        {selectedPharmacy && (
          <Popup
            position={[selectedPharmacy.latitude, selectedPharmacy.longitude]}
            onClose={() => setSelectedPharmacy(null)}
            style={popupStyles}
          >
            <div>
              <h3>{selectedPharmacy.name}</h3>
              {selectedPharmacy.cnpj && <p>CNPJ: {selectedPharmacy.cnpj}</p>}
              {selectedPharmacy.razaoSocial && <p>Razão Social: {selectedPharmacy.razaoSocial}</p>}
              {selectedPharmacy.nome && <p>Nome: {selectedPharmacy.nome}</p>}
              {selectedPharmacy.telefone && (
                <p>
                  Telefone:{" "}
                  <a href={`https://wa.me/55${selectedPharmacy.telefone}`} style={phoneLinkStyles}>
                    {selectedPharmacy.telefone}
                  </a>
                </p>
              )}
              {/* Adicione outros campos da farmácia aqui */}
              <span style={closeButtonStyles} onClick={() => setSelectedPharmacy(null)}>
                X
              </span>
            </div>
          </Popup>
        )}
      </MapContainer>
    </div>
  );
}

export default MapPage;
