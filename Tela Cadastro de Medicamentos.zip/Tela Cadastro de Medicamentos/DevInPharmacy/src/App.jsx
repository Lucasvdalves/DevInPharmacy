import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import CadastroFarmacia from './componentes/CadastroFarmacia/CadastroFarmacia';
import Login from './componentes/TelaDeLogin/Login';
import MedicamentoForm from './componentes/CadastroMedicamentos/MedicamentoForm';
import MainScreen from './componentes/TelaPrincipal/Principal'; // Importe o componente MainScreen

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/cadastro-farmacia" element={<CadastroFarmacia />} />
        <Route path="/" element={<Login />} />
        <Route path="/cadastro-medicamento" element={<MedicamentoForm />} />
        {/* Adicione a nova rota para o MainScreen */}
        <Route path="/main" element={<MainScreen />} />
      </Routes>
    </Router>
  );
}

export default App;
