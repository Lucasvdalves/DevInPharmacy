import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const MainScreen = () => {
  const navigate = useNavigate();

  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const carouselImages = [
    'image1.jpg',
    'image2.jpg',
    'image3.jpg',
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) =>
        (prevIndex + 1) % carouselImages.length
      );
    }, 5000); // Change image every 5 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="main-screen">
      <div className="carousel">
        <img
          src={carouselImages[currentImageIndex]}
          alt={`Image ${currentImageIndex + 1}`}
        />
      </div>
      <div className="company-description">
        <h2>About Us</h2>
        <p>
          Welcome to our company! We are a leading company in the industry,
          committed to delivering high-quality products and services to our
          clients.
        </p>
      </div>
      <div className="side-cards">
        <div className="card">
          <img src="card1.jpg" alt="Card 1" />
        </div>
        <div className="card">
          <img src="card2.jpg" alt="Card 2" />
        </div>
      </div>
    </div>
  );
};

export default MainScreen;
