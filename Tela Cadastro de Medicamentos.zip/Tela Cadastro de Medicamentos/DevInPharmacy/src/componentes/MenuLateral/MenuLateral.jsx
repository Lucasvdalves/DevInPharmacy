import React, { useState } from 'react';
import { FiHome, FiBarChart2, FiShoppingBag, FiRefreshCcw, FiSearch } from 'react-icons/fi';

const Sidebar = () => {
  const [hoveredItem, setHoveredItem] = useState(null);

  const handleMouseEnter = (index) => {
    setHoveredItem(index);
  };

  const handleMouseLeave = () => {
    setHoveredItem(null);
  };

  const isItemHovered = (index) => {
    return hoveredItem === index;
  };

  return (
    <div style={styles.container}>
      <div style={styles.sidebar}>
        <div style={styles.logo}></div>
        <nav style={styles.menu}>
          <ul style={styles.menuList}>
            <li
              style={{
                ...styles.menuItem,
                color: isItemHovered(0) ? '#000000' : 'white',
                backgroundColor: isItemHovered(0) ? '#ffffff' : 'transparent',
              }}
              onMouseEnter={() => handleMouseEnter(0)}
              onMouseLeave={handleMouseLeave}
            >
              <FiHome style={{ ...styles.icon, fontSize: '30px' }} />
              <span style={{ ...styles.menuText, fontWeight: 'bold' }}>Home</span>
            </li>
            <li
              style={{
                ...styles.menuItem,
                color: isItemHovered(1) ? '#000000' : 'white',
                backgroundColor: isItemHovered(1) ? '#ffffff' : 'transparent',
              }}
              onMouseEnter={() => handleMouseEnter(1)}
              onMouseLeave={handleMouseLeave}
            >
              <FiBarChart2 style={{ ...styles.icon, fontSize: '30px' }} />
              <span style={{ ...styles.menuText, fontWeight: 'bold' }}>Farmácias</span>
            </li>
            <li
              style={{
                ...styles.menuItem,
                color: isItemHovered(2) ? '#000000' : 'white',
                backgroundColor: isItemHovered(2) ? '#ffffff' : 'transparent',
              }}
              onMouseEnter={() => handleMouseEnter(2)}
              onMouseLeave={handleMouseLeave}
            >
              <FiShoppingBag style={{ ...styles.icon, fontSize: '30px' }} />
              <span style={{ ...styles.menuText, fontWeight: 'bold' }}>Medicamentos</span>
            </li>
            <li
              style={{
                ...styles.menuItem,
                color: isItemHovered(3) ? '#000000' : 'white',
                backgroundColor: isItemHovered(3) ? '#ffffff' : 'transparent',
              }}
              onMouseEnter={() => handleMouseEnter(3)}
              onMouseLeave={handleMouseLeave}
            >
              <FiRefreshCcw style={{ ...styles.icon, fontSize: '30px' }} />
              <span style={{ ...styles.menuText, fontWeight: 'bold' }}>Troca</span>
            </li>
            <li
              style={{
                ...styles.menuItem,
                color: isItemHovered(4) ? '#000000' : 'white',
                backgroundColor: isItemHovered(4) ? '#ffffff' : 'transparent',
              }}
              onMouseEnter={() => handleMouseEnter(4)}
              onMouseLeave={handleMouseLeave}
            >
              <FiSearch style={{ ...styles.icon, fontSize: '30px' }} />
              <span style={{ ...styles.menuText, fontWeight: 'bold' }}>Acompanhar Pedido</span>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
  },
  sidebar: {
    width: '240px',
    height: '100vh',
    color: 'black',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    paddingTop: '20px',
    paddingLeft: '10px',
    position: 'fixed',
    top: 0,
    left: 0,
    borderRight: '2px solid black',
  },
  logo: {
    marginTop: '50px',
    fontSize: '24px',
    marginBottom: '50px',
  },
  menu: {
    width: '100%',
  },
  menuList: {
    listStyleType: 'none',
    padding: 0,
  },
  menuItem: {
    marginLeft: '20px',
    display: 'flex',
    alignItems: 'center',
    marginBottom: '30px',
    marginTop: '10px',
    cursor: 'pointer',
    transition: 'background-color 0.8s ease, color 0.3s ease',
    borderRadius: '4px',
  },
  menuText: {
    fontSize: '22px',
  },
  icon: {
    marginRight: '15px',
    color: 'red',
  },
};

export default Sidebar;
