import React from 'react';
import { AiOutlineTwitter, AiOutlineInstagram, AiOutlineFacebook, AiOutlineLinkedin } from 'react-icons/ai';
import { FaGoogle, FaWhatsapp } from 'react-icons/fa';
import './Navbar.css'

const Navbar = () => {
  return (
    <div className="navbar">
      <div className="left-section">
        <FaGoogle className="logo" />
        <div className="contact-info">
          <p>contato@devinpharmacy.com.br</p>
        </div>
        <FaWhatsapp className="whatsapp-icon" />
        <p>(99) 1111-1333</p>
      </div>
      <div className="right-section">
        <AiOutlineTwitter className="social-icon" />
        <AiOutlineInstagram className="social-icon" />
        <AiOutlineFacebook className="social-icon" />
        <AiOutlineLinkedin className="social-icon" />
      </div>
    </div>
  );
}

export default Navbar;
