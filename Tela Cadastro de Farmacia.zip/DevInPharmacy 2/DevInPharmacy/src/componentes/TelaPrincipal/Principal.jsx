import CadastroFarmacia from "../CadastroFarmacia/CadastroFarmacia";
import { useState } from 'react'

function Principal() {
  const [count, setCount] = useState(0)

  return (
    <>
    <CadastroFarmacia/>
    </>
  )
}

export default Principal
