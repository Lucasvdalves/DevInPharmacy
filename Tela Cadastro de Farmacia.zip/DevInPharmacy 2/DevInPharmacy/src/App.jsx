import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import CadastroFarmacia from './componentes/CadastroFarmacia/CadastroFarmacia';
import Login from './componentes/TelaDeLogin/Login';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/cadastro-farmacia" element={<CadastroFarmacia />} />
        <Route path="/" element={<Login />} />
      </Routes>
    </Router>
  );
}

export default App;
