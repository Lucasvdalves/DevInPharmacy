import { useState } from 'react'
import Login from './componentes/TelaDeLogin/Login'


function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <Login/>
    </>
  )
}

export default App
